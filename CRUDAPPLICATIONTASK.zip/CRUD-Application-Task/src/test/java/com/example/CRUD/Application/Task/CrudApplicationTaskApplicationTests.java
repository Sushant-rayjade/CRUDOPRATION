package com.example.CRUD.Application.Task;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudApplicationTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}

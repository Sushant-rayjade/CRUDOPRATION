package com.example.CRUD.Application.Task;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudApplicationTaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudApplicationTaskApplication.class, args);
	System.err.println("Code Running Successfully");
	
	}

}

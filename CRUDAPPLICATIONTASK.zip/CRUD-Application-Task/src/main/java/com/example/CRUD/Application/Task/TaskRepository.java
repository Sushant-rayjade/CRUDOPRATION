package com.example.CRUD.Application.Task;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.scheduling.config.Task;

import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;


public interface TaskRepository extends JpaRepository<Task, Long> {

}
